package com.spring.app;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

//Provide the necessary annotations
@Configuration
@ComponentScan(basePackages="com.spring.app")
public class ApplicationConfig {

}
