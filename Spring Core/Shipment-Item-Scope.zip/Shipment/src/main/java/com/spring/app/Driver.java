package com.spring.app;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.Scanner;
public class Driver {

	public static void main(String[] args) {

        //Fill the code
        
        ApplicationContext ctx = new AnnotationConfigApplicationContext(ApplicationConfig.class);
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Shipment Details1");
        System.out.println("Enter the Item Name: ");
        String itemName1 = sc.nextLine();
        System.out.println("Enter the Item Price: ");
        double price1 = sc.nextDouble();
        sc.nextLine();
        System.out.println("Enter the ShipmentId: ");
        String shipmentId1 = sc.nextLine();
        System.out.println("Enter the Delivery Status: ");
        String status1 = sc.nextLine();
        
        Shipment shipment1 = ctx.getBean(Shipment.class);
        Item item1 = ctx.getBean(Item.class);
        item1.setPrice(price1);
        shipment1.setShipmentId(shipmentId1);
        shipment1.setItem(item1);
        shipment1.setDeliveryStatus(status1);
        
        System.out.println("\nShipment Details2");
        System.out.println("Enter the Item Name: ");
        String itemName2 = sc.nextLine();
        System.out.println("Enter the Item Price: ");
        double price2 = sc.nextDouble();
        sc.nextLine();
        System.out.println("Enter the ShipmentId: ");
        String shipmentId2 = sc.nextLine();
        System.out.println("Enter the Delivery Status: ");
        String status2 = sc.nextLine();
        
        Shipment shipment2 = ctx.getBean(Shipment.class);
        Item item2 = ctx.getBean(Item.class);
        item2.setPrice(price2);
        shipment2.setShipmentId(shipmentId2);
        shipment2.setItem(item2);
        shipment2.setDeliveryStatus(status2);
        
        System.out.println("\nDelivery status of shipment ID: "+ shipment1.getShipmentId()+" is "+shipment1.getDeliveryStatus());
        System.out.println("Delivery status of shipment ID: "+ shipment2.getShipmentId()+" is "+shipment2.getDeliveryStatus());

        sc.close();
        
		
	}	 

	
}
