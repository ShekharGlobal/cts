package com.hotel;

import java.text.ParseException;
import java.util.*;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import java.text.SimpleDateFormat;
import com.hotel.model.Reservation;
import com.hotel.service.ReservationService;

//Use appropriate annotations 
@Configuration
@ComponentScan(basePackages = "com.hotel")
@PropertySource("classpath:details.properties")
public class ApplicationConfig {
    public static void main(String[] args) throws ParseException {
        // Fill the Code Here
        
        ApplicationContext ctx = new AnnotationConfigApplicationContext(ApplicationConfig.class);
        
        ReservationService rs = ctx.getBean(ReservationService.class);
        
       /* Reservation re = ctx.getBean(Reservation.class);
        re.setCustomerName("Antony Praksh");
        re.setPhoneNumber(9000000L);
        re.setCheckInDate(new java.util.Date(2023,12,27));
        re.setCheckOutDate(new java.util.Date(2023,12,28));
        re.setNumOfGuests(2);
        re.setRoomType("Deluxe");
        rs.bookReservation(re);*/
        
        Scanner sc = new Scanner(System.in);
        SimpleDateFormat myFormat = new SimpleDateFormat("dd-MM-yyyy");
        System.out.println("Enter the Customer Name:");
        String customerName = sc.next();
        System.out.println("Enter the Phone Number");
        long phoneNumber = sc.nextLong();
        System.out.println("Enter the Check-In Date <dd-MM-yyyy>");
        Date CheckInDate = myFormat.parse(sc.next());
        System.out.println("Enter the Check-Out Date <dd-MM-yyyy>");
        Date CheckOutDate = myFormat.parse(sc.next());
        System.out.println("Enter the Total Number of Guests");
        int numOfGuests  = sc.nextInt();
        System.out.println("Enter the Room Type");
        String roomType = sc.next();
        System.out.println("Total Booking Cost is:$"+rs.calculateBookingCost(roomType,CheckInDate,CheckOutDate));
        
        
        
    }
}
