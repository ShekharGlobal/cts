package com.hotel.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.List;
import java.util.Scanner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.hotel.model.Hotel;
import com.hotel.model.Reservation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//use appropriate annotation to make this class as service class
@Service
public class ReservationService {
    
    //use appropriate annotation
    @Autowired
    private Hotel hotel;

    public void setHotel(Hotel hotel) {
        this.hotel = hotel;
    }
    
    public void bookReservation(Reservation re) throws ParseException {
	    
	    //Fill the code here 
	  /*  if(!checkAvailability(re.getCheckInDate(), re.getCheckOutDate() )){
	        System.out.println("Invalid Details");
	        return;
	    }
	    double totalCost = calculateBookingCost(re.getRoomType(),re.getCheckInDate(), re.getCheckOutDate());
	    if(totalCost == -1){
	        System.out.println("Invalid Details");
	        return;
	    }
	    System.out.println("Total Booking Cost is: $"+ totalCost);*/
	    

    }

    public double calculateBookingCost(String roomType, Date checkInDate, Date checkOutDate) {
        double roomRate = 0;
            
	    //Fill the code here 
	    
	    if(!checkAvailability(checkInDate, checkOutDate)){
	        System.out.println("Invalid Details");
	    }
	    long duration = TimeUnit.MILLISECONDS.toDays(checkOutDate.getTime()- checkInDate.getTime());
	    roomRate = hotel.getRoomRates().get(roomType)*duration;
        
           
        return roomRate ; 
    }

    public boolean checkAvailability(Date checkInDate, Date checkOutDate) {
        
        //Fill the code here 
	
	
	    return !checkInDate.after(checkOutDate);

    }
 
}