package com.spring.app;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
//Provide the necessary annotations
@Configuration
@ComponentScan(basePackages = "com.spring.app")
public class ApplicationConfig {
	
    //fill the code
    @Bean
    public Loan loan(){
        /*Loan loan = new Loan();
        loan.setLoanType("HomeLoan");
        loan.setLoanAmount(150000.0);*/
        return new Loan("HomeLoan", 150000.0);
    }
    
    @Bean
    public Account account(){
        /*Account account = new Account(loan());
        account.setAccNumber("335647852");
        account.setAccHolderName("Vanitha");
        account.setAccBalance(250000.0);*/
        return new Account("335647852","Vanitha",250000.0,loan());
    }
   
}

