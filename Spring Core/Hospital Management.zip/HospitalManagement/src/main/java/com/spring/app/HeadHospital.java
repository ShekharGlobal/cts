package com.spring.app;

public interface HeadHospital {
    
    public void doDocumentVerification();
    
    public void provideTreatment();
}
