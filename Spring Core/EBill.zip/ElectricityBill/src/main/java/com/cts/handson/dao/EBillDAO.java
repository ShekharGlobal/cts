package com.cts.handson.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.cts.handson.model.EBill;

@Service
@ComponentScan("com.cts.handson")
public class EBillDAO {
	@Autowired
	JdbcTemplate jdbcTemplate;
	@Autowired
	PlatformTransactionManager txManager;
	
	public void deleteBill(long...billNumbers) {
		DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = txManager.getTransaction(def);
		try {
			//delete business logic here
			for(long billNumber: billNumbers){
			    if(billNumber<100){
			        throw new Exception("Bill number less than 100");
			    }
			    jdbcTemplate.update("DELETE FROM ebill WHERE bill_number = ?", billNumber);
			}
			txManager.commit(status);
			
		}catch(Exception ex) {
			//roll back logic here
			txManager.rollback(status);
			throw new RuntimeException("Error deleting bills",ex);
		}
	}

	public List<EBill> getAllBill() {
		//retrieve business logic here
		return jdbcTemplate.query("SELECT bill_number,consumer_id,billing_month,reading,unit,amount FROM ebill", new BeanPropertyRowMapper<>(EBill.class));
	//	return null;
	}
}
