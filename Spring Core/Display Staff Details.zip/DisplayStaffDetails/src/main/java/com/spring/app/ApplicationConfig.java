package com.spring.app;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ComponentScan;

import java.util.Arrays;

//Use appropriate annotations
@Configuration
@ComponentScan(basePackages = "com.spring.app")
public class ApplicationConfig {

    //Use appropriate annotation 
    @Bean
    public Staff staff() {
         // FILL THE CODE HERE
	    return new Staff(1,"Ragul","CSE",9445543300L);
    }

    //Use appropriate annotation 
    @Bean
    public Department department() {
         // FILL THE CODE HERE
	   
	    return new Department(123,Arrays.asList(staff()));
    }
}
