package com.spring.app;
import org.springframework.context.ApplicationContext;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Driver {
    
    public static Department loadStaffDetails() {

        // FILL THE CODE HERE
        ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
        
        
        
	return context.getBean(Department.class);
    }

    public static void main(String[] args) {
        // FILL THE CODE HERE
        Department department = loadStaffDetails();
        department.displayStaffDetails();
    }
}
