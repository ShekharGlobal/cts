package com.app.driver;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.spring.app.StudentDAO;
import com.spring.app.ApplicationConfig;

 
public class Main {
 
	public static void main(String[] args) {
        ApplicationContext a = new AnnotationConfigApplicationContext(ApplicationConfig.class);
        StudentDAO s=a.getBean(StudentDAO.class);
        s.displayConfig();
 
 
		
	}
}