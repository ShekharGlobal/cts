package com.spring.app;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component
public class DBConfig {
    private String driverName;
    private String url;
    private String userName;
    private String password;
    
    
    public String getDriverName(){
        return driverName;
    }
    
    @Value("oracle.jdbc.driver.OracleDriver")
    public void setDriverName(String driverName){
        this.driverName = driverName;
    }
    
    public String getUrl(){
        return url;
    }
    
    @Value("jdbc:oracle:thin:@localhost:1521:oracle")
    public void setUrl(String url){
        this.url = url;
    }
    
    public String getUserName(){
        return userName;
    }
    
    @Value("alex")
    public void setUserName(String userName){
        this.userName = userName;
    }
    
    public String getPassword(){
        return password;
    }
    
    @Value("alex@123")
    public void setPassword(String password){
        this.password = password;
    }

}
