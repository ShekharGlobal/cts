package com.spring.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class  StudentDAO {
    private DBConfig dbConfig;
    public DBConfig getDbConfig(){
        return dbConfig;
    }
    
    @Autowired
    public void setDbConfig(DBConfig dbConfig){
        this.dbConfig = dbConfig;
    }
    
    public void displayConfig(){
        System.out.println(dbConfig.getDriverName());
        System.out.println(dbConfig.getUrl());
        System.out.println(dbConfig.getUserName());
        System.out.println(dbConfig.getPassword());
        
    }

}
