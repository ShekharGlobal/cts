package com.spring.app;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

public class SmartLoan {
	
		private Map<String, Double> interestRatesMap;
		
	 	public SmartLoan() {
	 	}
	 	
}
