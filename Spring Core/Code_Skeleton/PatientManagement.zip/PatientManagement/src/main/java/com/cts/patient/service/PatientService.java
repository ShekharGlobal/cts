package com.cts.patient.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cts.patient.model.Patient;

public class PatientService {

	//fill the code

	public void getPatientDetails() {
		//fill the code
	}
	
	
}
