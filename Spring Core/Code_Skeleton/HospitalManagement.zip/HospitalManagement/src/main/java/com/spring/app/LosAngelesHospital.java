package com.spring.app;

//use appropriate annotation to make this class as component class 
public class LosAngelesHospital  {

    private Document losAngelesDocument;
    
    //use appropriate annotation 
    public LosAngelesHospital(Document losAngelesDocument) {
        super();
        this.losAngelesDocument = losAngelesDocument;
    }

    // FILL THE CODE HERE
}
