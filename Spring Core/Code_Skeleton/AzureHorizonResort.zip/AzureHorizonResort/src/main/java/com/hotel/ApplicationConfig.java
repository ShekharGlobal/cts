package com.hotel;

import java.text.ParseException;

import com.hotel.model.Reservation;
import com.hotel.service.ReservationService;

//Use appropriate annotations 

public class ApplicationConfig {
    public static void main(String[] args) throws ParseException {
        // Fill the Code Here
        
        
    }
}
