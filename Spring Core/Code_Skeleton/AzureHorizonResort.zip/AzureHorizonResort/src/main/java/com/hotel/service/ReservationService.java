package com.hotel.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.hotel.model.Hotel;
import com.hotel.model.Reservation;

//use appropriate annotation to make this class as service class

public class ReservationService {
    
    //use appropriate annotation
    
    private Hotel hotel;

    public void setHotel(Hotel hotel) {
        this.hotel = hotel;
    }
    
    public void bookReservation(Reservation reservation) throws ParseException {
	    
	    //Fill the code here 

    }

    public double calculateBookingCost(String roomType, Date checkInDate, Date checkOutDate) {
        double roomRate = -1;
            
	    //Fill the code here 
        
           
        return roomRate ; 
    }

    public boolean checkAvailability(Date checkInDate, Date checkOutDate) {
        
        //Fill the code here 
	
	
	    return false;

    }
 
}