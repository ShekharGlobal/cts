package com.spring.app;


//use appropriate annotation to make this class as component class 
public class IncandescentLighting extends LightingSystem {
	    //use appropriate annotation
	    private int luminosity;
	    //use appropriate annotation
	    private int energyConsumption;
	    //use appropriate annotation
	    private String type;
	    
	    	public int getLuminosity() {
			return luminosity;
		}

		
		public void setLuminosity(int luminosity) {
			this.luminosity = luminosity;
		}

		public int getEnergyConsumption() {
			return energyConsumption;
		}

		 
		public void setEnergyConsumption(int energyConsumption) {
			this.energyConsumption = energyConsumption;
		}


		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}


	@Override
	public int getEfficiencyRating() {

		
	    // FILL THE CODE HERE
	    return 0;
	}

	

}
