package com.spring.app;



//Use appropriate annotations
public class ApplicationConfig {
    
	//Use appropriate annotation 
	public SmartHome ledHome(LEDLighting lightingSystem) {
	    // FILL THE CODE HERE
	    return null;
	}

	//Use appropriate annotation 
	public SmartHome incandescentHome(IncandescentLighting lightingSystem) {
	   // FILL THE CODE HERE
	   return null;
	}

}
