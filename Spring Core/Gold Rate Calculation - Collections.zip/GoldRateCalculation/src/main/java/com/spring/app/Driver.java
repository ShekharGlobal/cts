package com.spring.app;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.Scanner;

//Use appropriate annotations 
@Configuration
@ComponentScan("com.spring.app")
@PropertySource("classpath:goldRateDetails.properties")
public class Driver {
	
	public static GoldRateInfo loadGoldRateDetails() {
	    
		//Fill the code here
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Driver.class);
		return context.getBean(GoldRateInfo.class);
	}
	
    public static void main(String[] args){
	
	    Scanner in=new Scanner(System.in);
	    
	    // Fill the code here
	    System.out.println("Enter the carat:");
	    int carat = in.nextInt();
	    System.out.println("Enter Total Grams:");
	    double grams=in.nextDouble();
	    GoldRateInfo goldRateInfo = loadGoldRateDetails();
	    double totalRate = goldRateInfo.calculateGoldRate(carat,grams);
	    System.out.println("Total Gold Rate is Rs:"+totalRate);
	    
	
	
    }

}
	 	  	    	    		        	 	
