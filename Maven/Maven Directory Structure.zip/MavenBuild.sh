#Give the 'mvn' command here. Specify all the required parameters in the command-line itself
mvn archetype:generate \
-DgroupId=com.employee.project \
-DartifactId=EmployeeProject \
-DarchetypeArtifactId=maven-archetype-quickstart \
-DinteractiveMode=false