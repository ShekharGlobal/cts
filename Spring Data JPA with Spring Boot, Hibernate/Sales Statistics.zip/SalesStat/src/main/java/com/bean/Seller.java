package com.bean;
 
import jakarta.persistence.*;
import java.util.List;
 
@Entity
@Table(name = "Seller")
public class Seller {
    @Id
    @Column(name = "sellerId")
    private String sellerId;
 
    @Column(name = "sellerName")
    private String sellerName;
 
    @Column(name = "sellerContactNumber")
    private String sellerContactNumber;
 
    @OneToMany(mappedBy = "seller", cascade = CascadeType.ALL)
    private List<Car> carList;
 
    public String getSellerId() {
        return sellerId;
    }
 
    public void setSellerId(String sellerId) {
        this.sellerId = sellerId;
    }
 
    public String getSellerName() {
        return sellerName;
    }
 
    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }
 
    public String getSellerContactNumber() {
        return sellerContactNumber;
    }
 
    public void setSellerContactNumber(String sellerContactNumber) {
        this.sellerContactNumber = sellerContactNumber;
    }
 
    public List<Car> getCarList() {
        return carList;
    }
 
    public void setCarList(List<Car> carList) {
        this.carList = carList;
    }
}