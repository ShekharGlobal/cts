package com.bean;
import jakarta.persistence.*;
 
@Entity
@Table(name = "Car")
public class Car {
    @Id
    @Column(name = "regNumber")
    private String regNumber;
 
    @Column(name = "carName")
    private String carName;
 
    @Column(name = "carManufacturer")
    private String carManufacturer;
 
    @Column(name = "carModel")
    private String carModel;
 
    @Column(name = "carRegistrationDate")
    private String carRegistrationDate;
 
    @Column(name = "carPrice")
    private double carPrice;
 
    @ManyToOne
    @JoinColumn(name = "sellerid")
    private Seller seller;
 
    public String getRegNumber() {
        return regNumber;
    }
 
    public void setRegNumber(String regNumber) {
        this.regNumber = regNumber;
    }
 
    public String getCarName() {
        return carName;
    }
 
    public void setCarName(String carName) {
        this.carName = carName;
    }
 
    public String getCarManufacturer() {
        return carManufacturer;
    }
 
    public void setCarManufacturer(String carManufacturer) {
        this.carManufacturer = carManufacturer;
    }
 
    public String getCarModel() {
        return carModel;
    }
 
    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }
 
    public String getCarRegistrationDate() {
        return carRegistrationDate;
    }
 
    public void setCarRegistrationDate(String carRegistrationDate) {
        this.carRegistrationDate = carRegistrationDate;
    }
 
    public double getCarPrice() {
        return carPrice;
    }
 
    public void setCarPrice(double carPrice) {
        this.carPrice = carPrice;
    }
 
    public Seller getSeller() {
        return seller;
    }
 
    public void setSeller(Seller seller) {
        this.seller = seller;
    }
}