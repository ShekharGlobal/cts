package com;
 
import com.bean.Car;
import com.bean.Seller;
import com.dao.SellerDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
 
import java.util.List;
 
@SpringBootApplication
public class SalesStatApplication implements CommandLineRunner {
 
    @Autowired
    private SellerDAO sellerDAO;
 
    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(SalesStatApplication.class);
        app.run(args);
    }
 
    @Override
    public void run(String... args) throws Exception {
        System.out.println("Invoke the methods");
 
        // Example usage:
        Seller seller1 = new Seller();
        seller1.setSellerId("S1");
        seller1.setSellerName("John Doe");
        seller1.setSellerContactNumber("123-456-7890");
        sellerDAO.addSeller(seller1);
 
        Seller seller2 = new Seller();
        seller2.setSellerId("S2");
        seller2.setSellerName("Jane Smith");
        seller2.setSellerContactNumber("987-654-3210");
        sellerDAO.addSeller(seller2);
 
        Car car1 = new Car();
        car1.setRegNumber("C1");
        car1.setCarName("Toyota Camry");
        car1.setCarManufacturer("Toyota");
        car1.setCarModel("2023");
        car1.setCarRegistrationDate("2023-01-01");
        car1.setCarPrice(25000.0);
        sellerDAO.buyCar("S1", car1);
 
        Car car2 = new Car();
        car2.setRegNumber("C2");
        car2.setCarName("Honda Civic");
        car2.setCarManufacturer("Honda");
        car2.setCarModel("2022");
        car2.setCarRegistrationDate("2022-05-15");
        car2.setCarPrice(22000.0);
        sellerDAO.buyCar("S1", car2);
 
        Car car3 = new Car();
        car3.setRegNumber("C3");
        car3.setCarName("Ford Mustang");
        car3.setCarManufacturer("Ford");
        car3.setCarModel("2023");
        car3.setCarRegistrationDate("2023-03-10");
        car3.setCarPrice(40000.0);
        sellerDAO.buyCar("S2", car3);
 
        List<Seller> sellersWithMaxSales = sellerDAO.sellerWithMaximumSalesCount();
        System.out.println("Sellers with Maximum Sales:");
        for (Seller seller : sellersWithMaxSales) {
            System.out.println(seller.getSellerName());
        }
    }
}