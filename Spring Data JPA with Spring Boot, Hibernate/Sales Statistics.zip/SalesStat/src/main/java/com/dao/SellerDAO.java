package com.dao;
 
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Component;
import com.bean.Car;
import com.bean.Seller;
import com.repository.SellerRepository;
import com.repository.CarRepository;
 
@Component
public class SellerDAO {
    @Autowired
    private SellerRepository sellerRepository;
 
    @Autowired
    private CarRepository carRepository;
 
    public void addSeller(Seller seller) {
        sellerRepository.save(seller);
    }
 
    public void buyCar(String sellerId, Car car) {
        Seller seller = sellerRepository.findById(sellerId).orElse(null);
        if (seller != null) {
            car.setSeller(seller);
            carRepository.save(car);
        }
    }
 
    public List<Seller> sellerWithMaximumSalesCount() {
        return sellerRepository.findSellersWithMaxSales();
    }
}