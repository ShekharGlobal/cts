package com.repository;
 
import com.bean.Seller;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;
 
@Repository
public interface SellerRepository extends JpaRepository<Seller, String> {
    @Query("SELECT s FROM Seller s WHERE SIZE(s.carList) = (SELECT MAX(SIZE(ss.carList)) FROM Seller ss)")
    List<Seller> findSellersWithMaxSales();
}