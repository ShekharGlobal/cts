package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bean.School;

@Repository
public interface SchoolRepository extends JpaRepository<School,String>{


       
        
        
        @Query(value = "select s.* from school s join student st on s.school_id=st.schoolid where "+ 
              "s.city = :city group by s.school_id having count(st.student_roll_number)="+
              "(select max(cnt) from (select s.school_id,count(st.student_roll_number) cnt "+
              "from student st join school s on s.school_id=st.schoolid where s.city = :city "+
              "group by s.school_id) as temp1)",
                nativeQuery = true)
        
       
        List<School> findSchoolsWithMaxStudentsInCity(@Param("city") String city);
}	 	  	  		    	  	      	      	 	
