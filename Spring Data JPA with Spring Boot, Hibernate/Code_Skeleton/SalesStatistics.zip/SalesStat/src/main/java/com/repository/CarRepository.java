package com.repository;



public interface CarRepository  {

}
