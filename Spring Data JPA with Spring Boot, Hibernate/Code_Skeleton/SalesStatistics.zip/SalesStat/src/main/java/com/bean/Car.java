package com.bean;




public class Car {
	
	
	private String  regNumber ;
	private String carName ;  
	private String  carManufacturer ; 
	private String carModel ; 
	private String carRegistrationDate ; 
	private double carPrice ;
	
	private Seller seller;

	public String getRegNumber() {
		return regNumber;
	}

	public void setRegNumber(String regNumber) {
		this.regNumber = regNumber;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getCarManufacturer() {
		return carManufacturer;
	}

	public void setCarManufacturer(String carManufacturer) {	 	  	  		    	  	      	      	 	
		this.carManufacturer = carManufacturer;
	}

	public String getCarModel() {
		return carModel;
	}

	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}

	public String getCarRegistrationDate() {
		return carRegistrationDate;
	}

	public void setCarRegistrationDate(String carRegistrationDate) {
		this.carRegistrationDate = carRegistrationDate;
	}

	public double getCarPrice() {
		return carPrice;
	}

	public void setCarPrice(double carPrice) {
		this.carPrice = carPrice;
	}

	public Seller getSeller() {
		return seller;
	}

	public void setSeller(Seller seller) {
		this.seller = seller;
	}


}	 	  	  		    	  	      	      	 	
