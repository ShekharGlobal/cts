package com.repository;


public interface SellerRepository  {
	
	

}
