package com.bean;

import java.util.ArrayList;
import java.util.List;


public class Seller {
	
	 private String sellerId  ;
	 private String sellerName ;
	 private String sellerContactNumber ;
	 
	
	 private List<Car> carList=new ArrayList<Car>();

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getSellerName() {
		return sellerName;
	}

	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}

	public String getSellerContactNumber() {
		return sellerContactNumber;
	}

	public void setSellerContactNumber(String sellerContactNumber) {
		this.sellerContactNumber = sellerContactNumber;
	}	 	  	  		    	  	      	      	 	

	public List<Car> getCarList() {
		return carList;
	}

	public void setCarList(List<Car> carList) {
		this.carList = carList;
	}


}
