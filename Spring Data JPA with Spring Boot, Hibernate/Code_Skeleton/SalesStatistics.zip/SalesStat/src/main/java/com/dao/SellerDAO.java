package com.dao;


import java.util.List;

import org.springframework.stereotype.Repository;

import com.bean.Car;
import com.bean.Seller;


@Repository
public class SellerDAO {
	
	
	public void addSeller(Seller seller) {
		
	}

	
	public void buyCar(String sellerId, Car car) {
		
	}
	
	
	public List<Seller> sellerWithMaximumSalesCount(){
		return null;
		
	}
	
	
}
