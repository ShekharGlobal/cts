package com.bean;


public class CurrentAccount extends Account {
	
	private double ODLimit;

	public CurrentAccount() {
		
	}

	public double getODLimit() {
		return ODLimit;
	}

	public void setODLimit(double oDLimit) {
		ODLimit = oDLimit;
	}
	
	
          
}
