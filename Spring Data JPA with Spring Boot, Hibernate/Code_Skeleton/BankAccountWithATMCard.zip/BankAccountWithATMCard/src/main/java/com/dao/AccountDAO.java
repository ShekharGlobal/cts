package com.dao;

import java.util.List;


import com.bean.Account;

public class AccountDAO {
	
	public void openAccount(Account account) {
		//fill code
	}
	
	public List<Account> retrieveAccountBasedOnCardType(String cardType){
		//fill code
		return null;
		
	}
}
