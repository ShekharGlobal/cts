package com.repository;


public interface ATMCardRepository {

}
