package com.dao;

import com.bean.ATMCard;

public class ATMCardDAO {
	
	
	public void issueATMCardToAccount(int accountNumber, ATMCard atmCardObjet) {
			//fill code
	}

}
