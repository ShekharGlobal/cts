package com.repository;

public interface TransactionsRepository {

}
