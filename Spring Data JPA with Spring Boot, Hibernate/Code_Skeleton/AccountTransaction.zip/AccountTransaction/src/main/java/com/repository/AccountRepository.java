package com.repository;

public interface AccountRepository {

}
