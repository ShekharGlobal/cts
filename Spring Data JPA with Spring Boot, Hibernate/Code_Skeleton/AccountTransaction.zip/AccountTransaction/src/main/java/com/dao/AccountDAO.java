package com.dao;

import java.time.LocalDate;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.bean.Account;
import com.bean.Transactions;

@Repository
public class AccountDAO {

//Fill the code
	public void addAccount(Account account) {
		
	}
	
	public void performTransactionOnAccount(int accountNumber, Transactions transaction)
	{
		
	}

        public List<Transactions> retrieveTransactionDetails(int accountNumber, LocalDate startDate, LocalDate endDate)
	{
		return null;
	}


}
	 	  	  		    	  	      	      	 	
