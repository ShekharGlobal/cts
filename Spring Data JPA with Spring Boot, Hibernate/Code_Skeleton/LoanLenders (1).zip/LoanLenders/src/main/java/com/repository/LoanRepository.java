package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bean.Loan;

@Repository

public interface LoanRepository extends JpaRepository<Loan,Long>  {
	
	@Query("SELECT l from Loan l where l.monthlyDue= (select max(l2.monthlyDue )from Loan l2) AND l.repaymentYears = (select min(l3.repaymentYears) from Loan l3)")
    List<Loan> findLoanWithMaxDueMinYears();
	
}
