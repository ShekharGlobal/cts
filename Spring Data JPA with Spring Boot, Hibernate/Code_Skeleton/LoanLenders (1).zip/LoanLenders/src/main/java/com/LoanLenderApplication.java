package com;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.bean.Customer;
import com.bean.Loan;
import com.dao.BankDAO;

@SpringBootApplication
public class LoanLenderApplication implements CommandLineRunner {
	
	@Autowired
    private BankDAO bankDAO;

	public static void main(String[] args) {
		
		SpringApplication app = new SpringApplication(LoanLenderApplication.class);
       
        app.run(args);
	}
	
	 @Override
	    public void run(String... args) throws Exception {
		System.out.println("Invoke the methods");
		 Customer customer = new Customer();
	        customer.setCustomerName("John Doe");
	        customer.setCustomerContactNumber(1234567890L);
	        bankDAO.addCustomer(customer);

	        // Allocate a loan to the customer example
	        Loan loan = new Loan();
	        loan.setLoanType("Personal");
	        loan.setLoanAmount(5000);
	        loan.setRepaymentYears(5);
	        loan.setMonthlyDue(150);
	        // Assuming the customer ID is set manually or retrieved after adding the customer
	        bankDAO.allocateLoanToCustomer(customer.getCustomerId(), loan);

	        // Find the loan with the maximum due and minimum repayment years
	        List<Loan> loans = bankDAO.loanWithMaxDueMinYears();
	        System.out.println("Loans with max due and min years:");
	        for (Loan l : loans) {	 	  	  		    	  	      	      	 	
	            System.out.println("Loan ID: " + l.getLoanNumber() + ", Type: " + l.getLoanType() + ", Due: " + l.getMonthlyDue() + ", Years: " + l.getRepaymentYears());
	        }
	    }
}