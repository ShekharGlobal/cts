package com.bean;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Loan {
	
	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long loanNumber ;
	private  String loanType ; 
	private  double loanAmount ;
	private  int repaymentYears ; 
	private  double monthlyDue ;
	
	@ManyToOne
	@JoinColumn(name="customerid")
	private Customer customer;
	public long getLoanNumber() {
		return loanNumber;
	}
	public void setLoanNumber(long loanNumber) {
		this.loanNumber = loanNumber;
	}
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public int getRepaymentYears() {
		return repaymentYears;
	}
	public void setRepaymentYears(int repaymentYears) {
		this.repaymentYears = repaymentYears;
	}
	public double getMonthlyDue() {	 	  	      	 	    	      	    	      	 	
		return monthlyDue;
	}
	public void setMonthlyDue(double monthlyDue) {
		this.monthlyDue = monthlyDue;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	

	

}
