package com.dao;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.*;
import com.bean.Customer;
import com.bean.Loan;
import com.repository.CustomerRepository;
import com.repository.LoanRepository;

@Repository

public class BankDAO {
	
	  @Autowired
	    private CustomerRepository customerRepository;

	    @Autowired
	    private LoanRepository loanRepository;

	
	
	public void addCustomer(Customer customer) {
		
		customerRepository.save(customer);
	}
	
	public void allocateLoanToCustomer(long customerId, Loan loan) {
		
		Optional<Customer> customerOptional = customerRepository.findById(customerId);
		if(customerOptional!=null)
		{
			Customer customer =customerOptional.get();
			loan.setCustomer(customer);
			loanRepository.save(loan);
		}	 	  	  		    	  	      	      	 	
	}
	
	public List<Loan> loanWithMaxDueMinYears(){
		return loanRepository.findLoanWithMaxDueMinYears();
		
	}

}
