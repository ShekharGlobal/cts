package com.bean;
import jakarta.persistence.Entity;
import jakarta.persistence.DiscriminatorValue;

@Entity
@DiscriminatorValue("SAV")
public class SavingsAccount extends Account {
	
	private double minimumBalance;

	public SavingsAccount() {
		
	}
	
	public SavingsAccount(int accountNumber, String holderName, double balance,double minimumBalance){
	    super(accountNumber, holderName,balance);
	    this.minimumBalance = minimumBalance;
	} 
		
	public double getMinimumBalance() {
		return minimumBalance;
	}

	public void setMinimumBalance(double minimumBalance) {
		this.minimumBalance = minimumBalance;
	}
	
	

}
