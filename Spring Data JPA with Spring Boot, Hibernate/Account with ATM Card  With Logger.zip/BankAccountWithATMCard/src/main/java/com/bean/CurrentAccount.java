package com.bean;
import jakarta.persistence.Entity;
import jakarta.persistence.DiscriminatorValue;

@Entity
@DiscriminatorValue("CURR")
public class CurrentAccount extends Account {
	
	private double ODLimit;

	public CurrentAccount() {
		
	}
	
	public CurrentAccount( int accountNumber, String holderName, double balance, double oDLimit) {
		super(accountNumber, holderName,balance);
		ODLimit = oDLimit;
	}
	

	public double getODLimit() {
		return ODLimit;
	}

	public void setODLimit(double oDLimit) {
		ODLimit = oDLimit;
	}
	
	
          
}
