package com.repository;
import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.bean.Account;

public interface AccountRepository extends CrudRepository<Account, Integer>  {
    public List<Account> findByAtmCardCardType(String cardType);
}
