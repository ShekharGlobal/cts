package com.dao;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.PersistenceContext;
import jakarta.persistence.EntityManager;
import com.repository.AccountRepository;
import com.bean.Account;

@Repository
public class AccountDAO {
	
	Logger log = LoggerFactory.getLogger(AccountDAO.class);
	@Autowired
	AccountRepository accountRepo;
	@PersistenceContext
	private EntityManager em;
	
	public void openAccount(Account account) {
		//fill code
		accountRepo.save(account);
		log.info("Account with id "+account.getAccountNumber()+" added successfully");
	}
	
	public List<Account> retrieveAccountBasedOnCardType(String cardType){
		//fill code
		List<Account> accList = new ArrayList<Account>();
		accList = accountRepo.findByAtmCardCardType(cardType);
		
		if(accList.size()>0){
		    log.info("Account details with card type "+cardType+" retrieved successfully");
		}
		else{
		    log.error("No account with this card type "+cardType);
		}
		return accList;
		
	}
}
