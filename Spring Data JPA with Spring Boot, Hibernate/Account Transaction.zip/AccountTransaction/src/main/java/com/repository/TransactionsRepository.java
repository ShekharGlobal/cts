package com.repository;

import com.bean.Transactions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface TransactionsRepository extends JpaRepository<Transactions, Integer> {
    List<Transactions> findByAccount_AccountNumberAndTransactionDateBetween(int accountNumber, LocalDate startDate, LocalDate endDate);
}
