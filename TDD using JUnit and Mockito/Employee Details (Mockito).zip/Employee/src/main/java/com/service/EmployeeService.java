package com.service;

import com.model.Employee;
import com.repo.EmployeeRepo;
import java.util.List;

public class EmployeeService {
    private final EmployeeRepo employeeRepo;

    public EmployeeService(EmployeeRepo employeeRepo) {
        this.employeeRepo = employeeRepo;
    }

    public int addEmployee(Employee e) {
        return employeeRepo.addEmployeeToList(e);
    }

    public void deleteEmployee(Employee e) {
        employeeRepo.deleteEmployeeFromList(e);
    }

    public Employee fetchEmployeeById(int empId) {
        Employee employee = employeeRepo.getEmployeeByEmployeeId(empId);
        if (employee == null) {
            throw new NullPointerException("Employee not found.");
        }
        return employee;
    }

    public List<Employee> fetchEmployee() {
        List<Employee> employees = employeeRepo.getEmployee();
        if (employees.isEmpty()) {
            throw new RuntimeException("Empty List");
        }
        return employees;
    }
}
