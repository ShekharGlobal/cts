package com.test;

import com.model.Employee;
import com.repo.EmployeeRepo;
import com.service.EmployeeService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EmployeeTest {

    @Mock
    private EmployeeRepo employeeRepo;

    @InjectMocks
    private EmployeeService employeeService;

    @Test
    public void test1AddEmployee() {
        Employee employee = new Employee(1, "John Doe", "john@example.com", 50000.0);

        when(employeeRepo.addEmployeeToList(any(Employee.class))).thenReturn(1);

        int result = employeeService.addEmployee(employee);

        assertEquals(1, result, "Employee should be added successfully");
    }

    @Test
    public void test2DeleteEmployee() {
        Employee employee = new Employee(1, "Jane Doe", "jane@example.com", 60000.0);

        employeeService.deleteEmployee(employee);

        verify(employeeRepo, times(1)).deleteEmployeeFromList(employee);
    }

    @Test
    public void test3FetchEmployeeByEmployeeId() {
        Employee employee = new Employee(2, "Alice Smith", "alice@example.com", 55000.0);

        when(employeeRepo.getEmployeeByEmployeeId(2)).thenReturn(employee);

        Employee result = employeeService.fetchEmployeeById(2);

        assertNotNull(result);
        assertEquals(2, result.getEmployeeId());
        assertEquals("Alice Smith", result.getEmployeeName());
    }

    @Test
    public void test4FetchEmployeeByEmployeeIdWhenNull() {
        when(employeeRepo.getEmployeeByEmployeeId(999)).thenReturn(null);

        assertThrows(NullPointerException.class, () -> employeeService.fetchEmployeeById(999));
    }

    @Test
    public void test5FetchEmployee() {
        List<Employee> employeeList = new ArrayList<>();
        employeeList.add(new Employee(3, "Bob Brown", "bob@example.com", 48000.0));

        when(employeeRepo.getEmployee()).thenReturn(employeeList);

        List<Employee> result = employeeService.fetchEmployee();

        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertEquals("Bob Brown", result.get(0).getEmployeeName());
    }

    @Test
    public void test6FetchEmployeeEmptyList() {
        when(employeeRepo.getEmployee()).thenReturn(new ArrayList<>());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> employeeService.fetchEmployee());
        assertEquals("Empty List", exception.getMessage());
    }
}
