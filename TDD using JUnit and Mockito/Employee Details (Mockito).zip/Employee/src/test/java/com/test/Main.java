package com.test;

import com.model.Employee;
import com.repo.EmployeeRepo;
import com.service.EmployeeService;

public class Main {
    public static void main(String[] args) {
        EmployeeRepo employeeRepo = new EmployeeRepo();
        EmployeeService employeeService = new EmployeeService(employeeRepo);

        Employee employee1 = new Employee(1, "John Doe", "john@example.com", 50000.0);
        Employee employee2 = new Employee(2, "Jane Smith", "jane@example.com", 60000.0);

        employeeService.addEmployee(employee1);
        employeeService.addEmployee(employee2);

        System.out.println("Employees Added: " + employeeService.fetchEmployee());

        employeeService.deleteEmployee(employee1);
        System.out.println("After Deletion: " + employeeService.fetchEmployee());

        try {
            System.out.println("Fetching Employee By ID: " + employeeService.fetchEmployeeById(2));
            employeeService.fetchEmployeeById(999); // Should throw an exception
        } catch (NullPointerException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
