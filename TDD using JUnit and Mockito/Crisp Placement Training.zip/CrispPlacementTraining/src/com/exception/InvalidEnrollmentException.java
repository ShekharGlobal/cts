package com.exception;

public class InvalidEnrollmentException extends Exception {

    public InvalidEnrollmentException(String message) {
        super(message);
    }
}
