package com.model;

public class Student {
    private String studentId;
    private String studentName;
    private int age;
    private long phoneNumber;
    private String emailId;

    public Student() {
        // Default constructor
    }

    public Student(String studentId, String studentName, int age, long phoneNumber, String emailId) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.emailId = emailId;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
}
