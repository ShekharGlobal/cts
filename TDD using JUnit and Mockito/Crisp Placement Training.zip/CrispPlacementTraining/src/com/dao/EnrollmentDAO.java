package com.dao;

import java.util.ArrayList;
import java.util.List;
import com.exception.InvalidEnrollmentException;
import com.model.Enrollment;

public class EnrollmentDAO {
    private final List<Enrollment> enrollmentList = new ArrayList<>();

    public List<Enrollment> getEnrollmentList() {
        return enrollmentList;
    }

    public void addEnrollment(Enrollment enrollmentObj) throws InvalidEnrollmentException {
        if (enrollmentObj == null) {
            throw new InvalidEnrollmentException("Enrollment cannot be null");
        }
        enrollmentList.add(enrollmentObj);
    }

    public List<Enrollment> viewEnrollmentByCourseId(String courseId) {
        List<Enrollment> tempEnrollments = new ArrayList<>();
        for (Enrollment enrollment : enrollmentList) {
            if (enrollment.getCourse().getCourseId().equals(courseId)) {
                tempEnrollments.add(enrollment);
            }
        }
        return tempEnrollments;
    }
}
