package com.dao;

import com.model.Student;
import com.exception.InvalidStudentException;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {
    private final List<Student> studentList = new ArrayList<>();

    public void addStudent(Student studentObj) {
        studentList.add(studentObj);
    }

    public boolean deleteStudent(String studentId) throws InvalidStudentException {
        if (studentList.isEmpty()) {
            throw new InvalidStudentException("No students in list");
        }

        for (Student stu : studentList) {
            if (stu.getStudentId().equals(studentId)) {
                studentList.remove(stu);
                return true;
            }
        }

        throw new InvalidStudentException("Student Id does not exist");
    }

    public List<Student> viewAllStudent() throws InvalidStudentException {
        if (studentList.isEmpty()) {
            throw new InvalidStudentException("No students in list");
        }

        return studentList;
    }

    public Student viewStudentByStudentId(String studentId) throws InvalidStudentException {
        if (studentList.isEmpty()) {
            throw new InvalidStudentException("Student List is empty");
        }

        for (Student studentObj : studentList) {
            if (studentObj.getStudentId().equals(studentId)) {
                return studentObj;
            }
        }

        throw new InvalidStudentException("Student id does not exist");
    }
}
