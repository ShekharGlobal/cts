package com.dao;

import java.util.ArrayList;
import java.util.List;
import com.exception.InvalidCourseException;
import com.model.Course;

public class CourseDAO {
    private final List<Course> courseList = new ArrayList<>();

    public void addCourse(Course courseObj) {
        courseList.add(courseObj);
    }

    public Course viewCourseByCourseCoordinator(String courseInstructor) throws InvalidCourseException {
        if (courseList.isEmpty()) {
            throw new InvalidCourseException("Course List is empty");
        }

        for (Course c : courseList) {
            if (c.getCourseInstructor().equals(courseInstructor)) {
                return c;
            }
        }

        throw new InvalidCourseException("Course instructor is invalid");
    }
}
