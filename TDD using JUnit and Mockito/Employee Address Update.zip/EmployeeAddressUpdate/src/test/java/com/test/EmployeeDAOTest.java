package com.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.util.EmployeeDAO;
import com.exception.AddressUpdateException;

@ExtendWith(MockitoExtension.class)
public class EmployeeDAOTest {

    @Mock
    private DataSource dataSource;
    
    @Mock
    private Connection connection;
    
    @Mock
    private PreparedStatement preparedStatement;

    @InjectMocks
    private EmployeeDAO employeeDAO;

    @BeforeEach
    public void setUp() throws SQLException {
        lenient().when(dataSource.getConnection()).thenReturn(connection);
        lenient().when(connection.prepareStatement(anyString())).thenReturn(preparedStatement);
        lenient().when(preparedStatement.executeUpdate()).thenReturn(1);
    }

    @Test
    public void testInvalidEmployeeId() {
        AddressUpdateException exception = assertThrows(AddressUpdateException.class, () -> {
            employeeDAO.addressChange("123", "New Address");
        });
        assertEquals("Invalid Employee Id", exception.getMessage());
    }

    @Test
    public void testInvalidEmployeeAddress() {
        AddressUpdateException exception = assertThrows(AddressUpdateException.class, () -> {
            employeeDAO.addressChange("12345", null);
        });
        assertEquals("Invalid Employee Address", exception.getMessage());
    }

    @Test
    public void testInvalidEmployeeIdWithNull() {
        AddressUpdateException exception = assertThrows(AddressUpdateException.class, () -> {
            employeeDAO.addressChange(null, "New Address");
        });
        assertEquals("Invalid Employee Id", exception.getMessage());
    }

    @Test
    public void testMethodCall() throws SQLException, AddressUpdateException {
        boolean result = employeeDAO.addressChange("12345", "New Address");
        assertTrue(result);

        verify(dataSource, times(1)).getConnection();
        verify(connection, times(1)).prepareStatement(anyString());
        verify(preparedStatement, times(1)).executeUpdate();
    }
}
