package com.exception;

public class AddressUpdateException extends Exception{
	public AddressUpdateException() {
		super();
	}

	public AddressUpdateException(String message) {
		super(message);
	}

}
