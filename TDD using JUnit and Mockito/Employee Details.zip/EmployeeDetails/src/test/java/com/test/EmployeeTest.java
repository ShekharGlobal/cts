package com.test;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.model.Employee;
import com.util.EmployeeUtil;

public class EmployeeTest {

    private static Employee employee;

    @BeforeAll
    public static void setUp() {
        // Create an Employee object with valid attributes for testing
        employee = new Employee("EMP/123/2345", "John Doe", "FullTime", "Manager", "john.doe@example.com");
    }

    @Test
    public void test10_checkForValidEmployeeId() {
        assertTrue(EmployeeUtil.validateEmployeeId("EMP/123/2345"));
    }

    @Test
    public void test11_checkForInvalidEmployeeId() {
        assertFalse(EmployeeUtil.validateEmployeeId("INVALID_ID"));
    }

    @Test
    public void test12_checkForValidJobType() {
        assertEquals("FullTime", EmployeeUtil.validateJobType("FullTime"));
    }

    @Test
    public void test13_checkForValidEmployeeName() {
        assertEquals("John Doe", EmployeeUtil.findEmployeeName("John Doe"));
    }
}
