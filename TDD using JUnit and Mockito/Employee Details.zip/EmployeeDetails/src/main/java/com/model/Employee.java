package com.model;

public class Employee {
	
	private String employeeId;
	private String employeeName;
	private String jobType;
	private String designation;
	private String emailId;

	 public Employee(String employeeId,String employeeName, String jobType, String designation, String emailId) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.jobType = jobType;
		this.designation = designation;
		this.emailId = emailId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

    public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
}
