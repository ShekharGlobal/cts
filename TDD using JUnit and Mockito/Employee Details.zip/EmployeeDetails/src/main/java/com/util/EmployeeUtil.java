package com.util;

import java.util.regex.Pattern;

public class EmployeeUtil {

	private static String regex="[E]{1}[M]{1}[P]{1}[/][0-9]{3}[/][0-9]{4}";
	
	 public static boolean validateEmployeeId(String id){
	    if(Pattern.matches(regex,id))
	        return true;
	    else
	        return false;
	 }

	 public static String validateJobType(String jobType){
		 if(jobType.equals("FullTime"))
			 return jobType;
		 else
			 return null;
	}
	 
	 public static String findEmployeeName(String employeeName){
		 if(employeeName.length()==0)
			 return null;
		 else
			 return employeeName;
	}
}
