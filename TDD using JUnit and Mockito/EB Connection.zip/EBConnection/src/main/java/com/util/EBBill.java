package com.util;

import com.model.EBConnection;

public class EBBill {
	
	
	public static double calculateBillAmount(int units) {
    if (units < 0) {
        throw new IllegalArgumentException("Units cannot be negative");
    }
    
    if (units < 100) {
        return units * 2.60;
    } else if (units < 900) {
        return units * 3.25;
    } else {
        return units * 5.26;
    }
}

	
	public static boolean validateConnectionType(String connectionType)
	{
		if(connectionType.equals("Domestic")||connectionType.equals("Industrial"))
		return true;
		else
		{
			return false;
		}
	}

}
