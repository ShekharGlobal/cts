package com.model;

public class EBConnection {
	
	private String ebConnectionId;
	private String connectionType;
	private int units;
	
	public EBConnection(String ebConnectionId, String connectionType, int units) {
		super();
		this.ebConnectionId = ebConnectionId;
		this.connectionType = connectionType;
		this.units = units;
	}
	
	public String getEbConnectionId() {
		return ebConnectionId;
	}
	public void setEbConnectionId(String ebConnectionId) {
		this.ebConnectionId = ebConnectionId;
	}
	public String getConnectionType() {
		return connectionType;
	}
	public void setConnectionType(String connectionType) {
		this.connectionType = connectionType;
	}
	public int getUnits() {
		return units;
	}
	public void setUnits(int units) {
		this.units = units;
	}
	
	
	
	

}
