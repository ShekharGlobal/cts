package com.test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.model.EBConnection;
import com.util.EBBill;

public class EBBillTest {
    
    private static EBConnection ebConnection;

    @BeforeAll
    public static void setUp() throws Exception {
        ebConnection = new EBConnection("EB124567", "Domestic", 80);
    }

    @Test
    public void test1_calculateBillAmountForUnitLessThan100() {
        assertTrue(EBBill.calculateBillAmount(80) == 80 * 2.60);
    }

    @Test
    public void test2_calculateBillAmountForUnitEqualTo100() {
        assertTrue(EBBill.calculateBillAmount(100) == 100 * 3.25);
    }

    @Test
    public void test3_calculateBillAmountForUnitGreaterThan100() {
        assertTrue(EBBill.calculateBillAmount(150) == 150 * 3.25);
    }

    @Test
    public void test4_calculateBillAmountForUnitLessThan900() {
        assertTrue(EBBill.calculateBillAmount(850) == 850 * 3.25);
    }

    @Test
    public void test5_calculateBillAmountForUnitEqualTo900() {
        assertTrue(EBBill.calculateBillAmount(900) == 900 * 5.26);
    }

    @Test
    public void test6_calculateBillAmountForUnitGreaterThan900() {
        assertTrue(EBBill.calculateBillAmount(950) == 950 * 5.26);
    }

    @Test
    public void test7_validateConnectionType_Industrial() {
        assertTrue(EBBill.validateConnectionType("Industrial"));
    }

    @Test
    public void test8_validateConnectionType_Domestic() {
        assertTrue(EBBill.validateConnectionType("Domestic"));
    }

    @Test
    public void test9_validateConnectionType_Invalid() {
        assertFalse(EBBill.validateConnectionType("Commercial"));
    }

   @Test
public void test10_calculateBillAmountForAnInvalidUnits() {
    assertThrows(IllegalArgumentException.class, () -> {
        EBBill.calculateBillAmount(-50);
    });
}
}
