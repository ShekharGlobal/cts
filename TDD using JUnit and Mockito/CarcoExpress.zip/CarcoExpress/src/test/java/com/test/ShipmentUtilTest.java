package com.test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.model.Shipment;
import com.util.ShipmentUtil;

public class ShipmentUtilTest {

    private static Shipment shipment;

    @BeforeAll
    public static void setUp() {
        // Create a Shipment object with valid attributes
        shipment = new Shipment("ST0010", "Standard", 24.0);
    }

    @Test
    public void test1_ValidateForValidShipmentTypeStandard() {
        assertTrue(ShipmentUtil.validateShipmentType("Standard"));
    }

    @Test
    public void test2_ValidateForValidShipmentTypeExpress() {
        assertTrue(ShipmentUtil.validateShipmentType("Express"));
    }

    @Test
    public void test3_ValidateForValidShipmentTypeOvernight() {
        assertTrue(ShipmentUtil.validateShipmentType("Overnight"));
    }

    @Test
    public void test4_ValidateForInvalidShipmentType() {
        assertFalse(ShipmentUtil.validateShipmentType("Priority"));
    }

    @Test
    public void test5_CalculateShippingCostForStandard() {
        assertTrue(ShipmentUtil.calculateShippingCost("Standard", 24.0) == 24.0 * 50);
    }

    @Test
    public void test6_CalculateShippingCostForExpress() {
        assertTrue(ShipmentUtil.calculateShippingCost("Express", 24.0) == 24.0 * 100);
    }

    @Test
    public void test7_CalculateShippingCostForOvernight() {
        assertTrue(ShipmentUtil.calculateShippingCost("Overnight", 24.0) == 24.0 * 200);
    }

    @Test
    public void test8_CalculateShippingCostForInvalidShipmentType() {
        assertTrue(ShipmentUtil.calculateShippingCost("InvalidType", 24.0) == 0.0);
    }
}
