package com.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.util.Square;
import com.util.MathApplication;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class MathApplicationTest {

    @Mock
    private Square square;

    @InjectMocks
    private MathApplication mathApplication;

    @BeforeEach
    public void setUp() {
        // Removed unnecessary stubbing
    }

    @Test
    public void testSuccess() {
        int validSide = 5;

        mathApplication.assignSide(validSide);

        verify(square, times(1)).setSide(validSide);
    }

    @Test
    public void testFailed() {
        int invalidSide = -1;

        try {
            mathApplication.assignSide(invalidSide);
        } catch (RuntimeException e) {
            assertEquals("Invalid Input", e.getMessage());
        }

        verify(square, never()).setSide(anyInt());
    }

    @Test
    public void testException() {
        int invalidSide = 0;

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            mathApplication.assignSide(invalidSide);
        });

        assertEquals("Invalid Input", exception.getMessage());
    }
}
