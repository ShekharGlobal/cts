package com.util;

public class MathApplication {
	private Square square;

	public MathApplication(Square square) {
		super();
		this.square = square;
	}
	
	public Square assignSide(int side) {
		if(side>0) {
			square.setSide(side);
		}else {
			throw new RuntimeException("Invalid Input");
		}
		return square;
	}
}
