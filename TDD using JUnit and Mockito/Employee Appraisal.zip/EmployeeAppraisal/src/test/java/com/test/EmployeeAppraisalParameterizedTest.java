package com.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import com.util.EmployeeAppraisalService;

public class EmployeeAppraisalParameterizedTest {

    // Provide sample data using MethodSource
    static Stream<Arguments> data() {
        return Stream.of(
            Arguments.of("EMP001", "John Doe", "HR", 50000, 0.9, 50000),  // Rating too low, salary unchanged
            Arguments.of("EMP002", "Jane Smith", "IT", 60000, 1.0, 66000), // 10% increment
            Arguments.of("EMP003", "Alice Brown", "Finance", 75000, 3.0, 82500), // 10% increment
            Arguments.of("EMP004", "Bob Green", "Marketing", 55000, 3.1, 66000), // 20% increment
            Arguments.of("EMP005", "Charlie Black", "Operations", 70000, 4.5, 91000), // 30% increment
            Arguments.of("EMP006", "Eve White", "HR", 48000, 5.1, 48000)  // Rating too high, salary unchanged
        );
    }

    @ParameterizedTest
    @MethodSource("data")
    public void testCalculateIncrement(String empId, String name, String dept, double salary, double rating, double expectedIncrementedSalary) {
        assertEquals(expectedIncrementedSalary, EmployeeAppraisalService.calculateIncrement(salary, rating));
    }
}
