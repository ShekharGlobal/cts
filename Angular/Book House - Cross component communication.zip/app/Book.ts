export class Book {

    constructor(public isbn: string, public  bookName: string,public category:string,  public  price:number,quantity:number) {  }
      //  constructor(){}
      
      
}
