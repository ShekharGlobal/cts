import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-boatride',
  templateUrl: './boatride.component.html',
  styleUrls: ['./boatride.component.css']
})
export class BoatrideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
