//Dont do any changes in this file

export class Student{
    public name : String;
    public registerNumber :String;
    public age : number;
    constructor(name : string , registerNumber : String ,age : number){
        this.name = name;
        this.registerNumber = registerNumber;
        this.age = age;
    }
}