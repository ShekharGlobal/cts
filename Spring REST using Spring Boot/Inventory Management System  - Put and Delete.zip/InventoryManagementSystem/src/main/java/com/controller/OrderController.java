package com.controller;

import com.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class OrderController {	
	@Autowired
	private OrderService orderService;
	@RequestMapping(value = "/BHO/updateBookQuantity/{id}/{booksCount}",method = RequestMethod.PATCH)
	public boolean updateBookQuantity(@PathVariable int id, @PathVariable int booksCount) {	
        return orderService.updateBookQuantity(id, booksCount);
    }
    @RequestMapping(value = "/BHO/deleteOrder/{id}",method = RequestMethod.DELETE)
   	public boolean deleteOrder(@PathVariable int id)	{
		return orderService.deleteOrder(id);
	}	
}
