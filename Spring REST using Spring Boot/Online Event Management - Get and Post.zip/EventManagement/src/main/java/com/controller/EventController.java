package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Event;
import com.service.EventService;

@RestController
public class EventController {	
	
	 @Autowired
	    private EventService eventService;
	 
	
	 @PostMapping("/OEMS/addEvent")
	    public boolean addEvent(@RequestBody Event eventObj) {
	        return eventService.addEvent(eventObj);
	    }
	
	 @GetMapping("/OEMS/findEventById/{eventId}")
	    public Event findEventById(@PathVariable("eventId") int eventId) {
	        return eventService.findEventById(eventId);
	    }
	
	
	@GetMapping("/OEMS/findAllEvents")
    public List<Event> findAllEvents() {
        return eventService.findAllEvents();
    }
	

	
}
	 	  	    	    		        	 	
