package com.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exception.PatientNotFoundException;
import com.model.Patient;
import com.service.PatientService;

@RestController
@RequestMapping("/pms")
public class PatientController {
	
	@Autowired
	private PatientService patientService;
	
	@GetMapping("/find/{patientId}")
	public Patient findPatient(@PathVariable Integer patientId) {
		
		Patient c1=patientService.searchPatient(patientId);
		if(c1==null)
		{
			throw new PatientNotFoundException("No such patient id");
		}
		else
			return c1;
	
		
	}
	


}
	 	  	    	    		        	 	
