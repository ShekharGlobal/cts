package com.controller;

import java.util.List;
import com.model.MovieCatalog;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

import com.model.Movie;

@RestController
public class MovieRestController {

    @RequestMapping(value = "/movies")
 	public  List<Movie> getAllMovies() 
    {
        MovieCatalog mov = new MovieCatalog();
        return mov.getMovieList();
         
     }
}
