package com.model;
import java.util.ArrayList;

public class MovieCatalog {
	
	private ArrayList<Movie> movieList=new ArrayList<Movie>();

	public ArrayList<Movie> getMovieList() {
		return movieList;
	}

	public void setMovieList(ArrayList<Movie> movieList) {
		this.movieList = movieList;
	}

	public MovieCatalog() {
		Movie mOne = new Movie(1,"Hinana",180);
		Movie mTwo = new Movie(2,"TheLittleMermaid",150);
		Movie mThree = new Movie(3,"Chitha",180);
		movieList.add(mOne);
		movieList.add(mTwo);
		movieList.add(mThree);
	}

}
