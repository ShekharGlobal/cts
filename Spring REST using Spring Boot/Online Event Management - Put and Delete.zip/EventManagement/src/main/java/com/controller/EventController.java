package com.controller;

import java.util.List;

import com.model.Event;
import com.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/OEMS")
public class EventController {	
	
	    @Autowired
	    private EventService eventService;
	 
	@PutMapping("/updateEventType/{eventId}/{eventType}")
    public boolean updateEventType(@PathVariable Integer eventId,@PathVariable String eventType) {
        return eventService.updateEventType(eventId, eventType);
    }

    @DeleteMapping("/deleteEvent/{eventId}")
    public boolean deleteEvent(@PathVariable Integer eventId) {
        return eventService.deleteEvent(eventId);
    }
	
}