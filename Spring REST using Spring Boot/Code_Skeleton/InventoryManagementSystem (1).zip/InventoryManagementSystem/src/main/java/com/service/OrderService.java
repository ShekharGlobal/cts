package com.service;

import java.util.ArrayList;

import org.springframework.stereotype.Component;

import com.model.Order;

@Component
public class OrderService {

	ArrayList<Order> orderList = new ArrayList<Order>();
	
	public ArrayList<Order> getOrderList() {
		return orderList;
	}

	public void setOrderList(ArrayList<Order> orderList) {
		this.orderList = orderList;
	}

	public OrderService(){
		Order orderObj1=new Order(101,"sathya",10,true);
		Order orderObj2=new Order(102,"priya",6,false);
		orderList.add(orderObj1);
		orderList.add(orderObj2);
		
	}
	
	public boolean addOrder(Order orderObj)
	{
		return false;
	}
	
	public ArrayList<Order> viewAllOrders()
	{
		return null;
	}
	
	public Order findOrderById(int id)
	{
		return null;
	}
}
