package com.controller;

import java.util.List;

import com.model.Order;
import com.service.OrderService;

public class OrderController {	
	
	private OrderService orderService;
	
	
	public boolean addOrder(Order orderObj) {		
		return false;
	}
	
	public Order findOrderById(int id) {
			return null;	
	}
	
	public List<Order> viewAllOrders() {
		return null;
	}	
	
}
