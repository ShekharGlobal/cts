package com.model;

public class Order {
	private int id;
    private String customerName;
    private int booksCount;
    private boolean processed;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getBooksCount() {
		return booksCount;
	}
	public void setBooksCount(int booksCount) {
		this.booksCount = booksCount;
	}
	
	public boolean isProcessed() {
		return processed;
	}
	public void setProcessed(boolean processed) {
		this.processed = processed;
	}
	public Order(int id, String customerName, int booksCount, boolean processed) {
		super();
		this.id = id;
		this.customerName = customerName;
		this.booksCount = booksCount;
		this.processed = processed;
	}
	public Order() {
		super();
	}

	
}
