package com.example.demo;

import org.springframework.boot.SpringApplication;
// provide proper annotations
public class OnlineRecipeManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineRecipeManagementApplication.class, args);
	}

}
