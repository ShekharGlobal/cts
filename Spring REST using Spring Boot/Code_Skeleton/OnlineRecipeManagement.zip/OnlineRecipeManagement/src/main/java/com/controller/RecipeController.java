package com.controller;

import com.model.Recipe;
import com.service.RecipeService;

public class RecipeController {

	//include the appropraiate annotation
		private RecipeService recipeService;
		
		
	//include the appropriate annotation
		public Recipe findRecipe(int recipeId) 	{
		
	//include the appropriate business logic	
		return null;
		
		

		}
}
