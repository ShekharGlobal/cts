package com.exception;
//include the appropriate annotation to change the status
public class RecipeNotFoundException extends RuntimeException
{
	//include a one argument constructor of type String and write the code to pass the message to the super class


}
