package com.controller;

import com.service.OrderService;


public class OrderController {	
	
	private OrderService orderService;
	
	public boolean updateBookQuantity(int id,int booksCount) {	
        return false;
    }
    
   	public boolean deleteOrder(int id)	{
		return false;
	}	
}
