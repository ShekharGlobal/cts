package com.example.demo;

import org.springframework.boot.SpringApplication;

// provide proper annotations
public class InventoryManagementSystemApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(InventoryManagementSystemApplication.class, args);
	
	}
}
