package com.model;

public class Movie {
	private int movieId;
	private String movieName;
	private int durationMinutes;
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public int getDurationMinutes() {
		return durationMinutes;
	}
	public void setDurationMinutes(int durationMinutes) {
		this.durationMinutes = durationMinutes;
	}
	public Movie(int movieId, String movieName, int durationMinutes) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.durationMinutes = durationMinutes;
	}
	public Movie() {
		super();
	}

}
