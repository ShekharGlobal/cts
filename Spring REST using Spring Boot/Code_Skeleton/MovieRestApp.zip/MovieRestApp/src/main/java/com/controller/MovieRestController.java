package com.controller;

import java.util.List;

import com.model.Movie;

public class MovieRestController {


 	public  List<Movie> getAllMovies() 
    {
        //Include the required business logic to return the list of movies

        return null;
         
     }
}
