package com.example.demo;

import org.springframework.boot.SpringApplication;

// provide necessary annotations
public class MovieRestAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieRestAppApplication.class, args);
	}

}
