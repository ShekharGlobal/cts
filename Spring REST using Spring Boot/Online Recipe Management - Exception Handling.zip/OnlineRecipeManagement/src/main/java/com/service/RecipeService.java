package com.service;

import org.springframework.stereotype.Service;
import java.util.*;
import com.model.Recipe;

@Service
public class RecipeService {
ArrayList<Recipe> recipeList=new ArrayList<Recipe>();
	
	
	public RecipeService() {
		Recipe r1=new Recipe(101,"mushroomtikka","veg");
		Recipe r2=new Recipe(102,"gravy", "nonveg");
		recipeList.add(r1);
		recipeList.add(r2);
		
	}
	
	public Recipe findRecipe(int recipeId)
	{
		Recipe r=null;
		for(Recipe rObj: recipeList)
		{
			if(rObj.getRecipeId()==recipeId)
			{
				r=rObj;
				break;
			}
		}
		return r;
	}

	public ArrayList<Recipe> getRecipeList() {
		return recipeList;
	}

	public void setRecipeList(ArrayList<Recipe> recipeList) {
		this.recipeList = recipeList;
	}

	
}
